

var Vssr = {
    init: function () {

    }
}


$(document).ready(function () {
    Vssr.init();
});

$(window).load(function () {

});